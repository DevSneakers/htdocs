<!DOCTYPE html>
<html>
    <head>
        <title>Temp and Humidity Output</title>
        <style>
            table, th, td {
                border: 1px solid #bcbcbc;
            }
            table {
                width: 300px;
                height: 50px;
            }
            td {
                text-align: center;
            }
            div.DHT{
                width:700px;
                height:250px;
            }
            div.left{
                width:50%;
                float:left;
                box-sizing:border-box;
            }
            div.right{
                width:50%;
                float:right;
                box-sizing:border-box;
            }
        </style>
    </head>
    <body>
        <?php
            $con=mysqli_connect("localhost","sensor_admin","kApRympaUfsSlA*B","all_sensor_data");

            if(mysqli_connect_error())
            {
            echo "Failed to MySQL:".mysqli_connect_error();
            }

            else{
            $now_data="SELECT *FROM quality_meter ORDER BY id DESC LIMIT 1";
            $prev_data="SELECT *FROM quality_meter ORDER BY id DESC LIMIT 1,1";
            $max_temp="SELECT *FROM quality_meter ORDER BY temp_D DESC LIMIT 1";
            $min_temp="SELECT *FROM quality_meter ORDER BY temp_D ASC LIMIT 1";
            $max_humi="SELECT *FROM quality_meter ORDER BY humidity_D DESC LIMIT 1";
            $min_humi="SELECT *FROM quality_meter ORDER BY humidity_D ASC LIMIT 1";

            $result_nowdata=mysqli_query($con, $now_data);
            $result_prevdata=mysqli_query($con, $prev_data);
            $result_maxtemp=mysqli_query($con, $max_temp);
            $result_mintemp=mysqli_query($con, $min_temp);
            $result_maxhumi=mysqli_query($con, $max_humi);
            $result_minhumi=mysqli_query($con, $min_humi);

            $row_nowdata=mysqli_fetch_array($result_nowdata);
            $row_prevdata=mysqli_fetch_array($result_prevdata);
            $row_maxtemp=mysqli_fetch_array($result_maxtemp);
            $row_mintemp=mysqli_fetch_array($result_mintemp);
            $row_maxhumi=mysqli_fetch_array($result_maxhumi);
            $row_minhumi=mysqli_fetch_array($result_minhumi);
            
            echo "<div class='DHT'>";
                echo"<div class='left'>";
                    echo"<br>";
                    echo"현재 데이터";
                    echo"<table border='2'>";
                        echo"<tr><th>온도</th><th>습도</th><th>측정 시간</th></tr>";
                        echo"<td>";
                            echo $row_nowdata['temp_D'].'&#176C';
                        echo"</td>";
                        echo"<td>";
                            echo $row_nowdata['humidity_D'].'%';
                        echo"</td>";
                        echo"<td>";
                            echo $row_nowdata['Time'];
                        echo"</td>";
                    echo"</table>";
                        
                    echo"<br>";

                    echo"<table border='2'>";
                        echo"<tr><th>최고 온도</th><th>측정 시간</th></tr>";
                        echo"<td>";
                            echo $row_maxtemp['temp_D'].'&#176C';
                        echo"</td>";
                        echo"<td>";
                            echo $row_maxtemp['Time'];
                        echo"</td>";
                        echo"<tr><th>최저 온도</th><th>측정 시간</th></tr>";
                        echo"<td>";
                            echo $row_mintemp['temp_D'].'&#176C';
                        echo"</td>";
                        echo"<td>";
                            echo $row_mintemp['Time'];
                        echo"</td>";
                    echo"</table>";
                echo"</div>";

                echo"<div class='right'>";
                    echo"<br>";
                    echo"이전 데이터";
                    echo"<table border='2'>";
                    echo"<tr><th>온도</th><th>습도</th><th>측정 시간</th></tr>";
                        echo"<td>";
                            echo $row_prevdata['temp_D'].'&#176C';
                        echo"</td>";
                        echo"<td>";
                            echo $row_prevdata['humidity_D'].'%';
                        echo"</td>";
                        echo"<td>";
                            echo $row_prevdata['Time'];
                        echo"</td>";
                    echo"</table>";
                    
                    echo"<br>";

                    echo"<table border='2'>";
                    echo"<tr><th>최고 습도</th><th>측정 시간</th></tr>";
                    echo"<td>";
                        echo $row_maxhumi['humidity_D'].'%';
                    echo"</td>";
                    echo"<td>";
                        echo $row_maxhumi['Time'];
                    echo"</td>";
                    echo"<tr><th>최저 습도</th><th>측정 시간</th></tr>";
                    echo"<td>";
                        echo $row_minhumi['humidity_D'].'%';
                    echo"</td>";
                    echo"<td>";
                        echo $row_minhumi['Time'];
                    echo"</td>";
                    echo"</table>";
                echo"</div>";
            echo "</div>";
            mysqli_close($con);
            }
        ?>
    </body>
</html>